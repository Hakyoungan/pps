#큰 수 A+B
#크기가 큰 두 정수 A와 B를 입력받은 다음, A+B를 출력하는 문제

# 크기가 큰 두 정수를 입력받기
A, B = map(int, input().split())

result = A + B

print(result)
